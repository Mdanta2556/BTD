import telebot
import yt_dlp
import os
import uuid
import time
import threading
from telebot import types

# === SETTINGS ===
REQUIRED_CHANNEL = "@mdantaX"
TOKEN_FILE = "Token.env.txt"
WELCOME_VIDEO = "FullSaveMeBot_start_en.mp4"
DOWNLOAD_DIR = "downloads"
STICKER_AFTER_VIDEO = "CAACAgQAAxkBAXvaFmhhPele1Csa_MgkmA78aEA_7MnBAALWDwACa4upUXb4YT1-rEscNgQ"

# === READ BOT TOKEN ===
with open(TOKEN_FILE, "r") as f:
    TOKEN = f.read().split("=")[1].strip()

bot = telebot.TeleBot(TOKEN)
os.makedirs(DOWNLOAD_DIR, exist_ok=True)

# === CHECK USER MEMBERSHIP ===
def is_user_joined(user_id):
    try:
        member = bot.get_chat_member(REQUIRED_CHANNEL, user_id)
        return member.status in ["member", "creator", "administrator"]
    except:
        return False

# === DOWNLOAD VIDEO ===
def download_video(url):
    filename = f"{DOWNLOAD_DIR}/{uuid.uuid4().hex}.mp4"
    ydl_opts = {
        'format': 'best',
        'outtmpl': filename,
        'quiet': True,
        'noplaylist': True,
        'merge_output_format': 'mp4',
    }
    with yt_dlp.YoutubeDL(ydl_opts) as ydl:
        ydl.download([url])
    return filename

# === WELCOME VIDEO FUNCTION ===
def send_welcome_video(chat_id):
    username = bot.get_chat(chat_id).first_name or "there"
    caption = (
        f"👋 Welcome to your *Ultimate Video Downloader Bot*, *{username}*! 🎬\n\n"
        "🚀 Send me any video link from:\n"
        "📸 Instagram\n🎵 TikTok\n📘 Facebook\n\n"
        "📥 I’ll fetch the video for you in seconds – *simple*, *fast*, and *no watermark*."
    )
    markup = types.InlineKeyboardMarkup(row_width=1)
    markup.add(
        types.InlineKeyboardButton("➕ Add to Chat", url=f"https://t.me/{bot.get_me().username}?startgroup=true"),
        types.InlineKeyboardButton("👥 Invite Friends", url=f"https://t.me/share/url?url=https://t.me/{bot.get_me().username}")
    )
    with open(WELCOME_VIDEO, "rb") as video:
        bot.send_video(chat_id, video, caption=caption, parse_mode="Markdown", reply_markup=markup)

# === /start COMMAND ===
@bot.message_handler(commands=['start'])
def start(message):
    user_id = message.chat.id
    if not is_user_joined(user_id):
        markup = types.InlineKeyboardMarkup(row_width=1)
        markup.add(
            types.InlineKeyboardButton("🔗 Join Channel", url=f"https://t.me/{REQUIRED_CHANNEL.lstrip('@')}"),
            types.InlineKeyboardButton("✅ Done", callback_data="check_joined")
        )
        bot.send_message(user_id, "🚫 Please join our channel to use this bot.", reply_markup=markup)
        return
    send_welcome_video(user_id)

# === CALLBACK QUERY FOR JOIN ===
@bot.callback_query_handler(func=lambda call: call.data == "check_joined")
def check_joined(call):
    user_id = call.message.chat.id
    if is_user_joined(user_id):
        bot.delete_message(user_id, call.message.message_id)
        send_welcome_video(user_id)
    else:
        bot.answer_callback_query(call.id, "❌ You haven't joined yet.", show_alert=True)

# === CREATE YOUR BOT INFO ===
@bot.message_handler(func=lambda msg: msg.text == "➕ Create Your Bot")
def bot_creator_info(message):
    bot.send_message(
        message.chat.id,
        "🤖 Want your own bot like this?\n\nCreate it now 👉 @VidBotCreatorBot\n\n🔧 Powered by @mdantaX",
        parse_mode="Markdown"
    )

# === HANDLE VIDEO LINKS ===
@bot.message_handler(func=lambda msg: any(domain in msg.text.lower() for domain in ['instagram.com', 'tiktok.com', 'facebook.com', 'fb.watch']))
def handle_video(message):
    chat_id = message.chat.id
    url = message.text.strip()

    if not is_user_joined(chat_id):
        markup = types.InlineKeyboardMarkup(row_width=1)
        markup.add(
            types.InlineKeyboardButton("🔗 Join Channel", url=f"https://t.me/{REQUIRED_CHANNEL.lstrip('@')}"),
            types.InlineKeyboardButton("✅ Done", callback_data="check_joined")
        )
        bot.send_message(chat_id, "🚫 Please join our channel to use this bot.", reply_markup=markup)
        return

    reaction_msg = bot.send_message(chat_id, "👀", reply_to_message_id=message.message_id)
    loading_msg = bot.send_message(chat_id, "📥 Downloading your video, please wait...")

    try:
        video = download_video(url)

        if os.path.getsize(video) > 50 * 1024 * 1024:
            bot.send_message(chat_id, "⚠️ Video is too large to send (limit is 50MB).")
            os.remove(video)
            return

        with open(video, 'rb') as f:
            bot.send_video(chat_id, f, caption="@Videosaver254_bot", reply_to_message_id=message.message_id)

        os.remove(video)
        bot.delete_message(chat_id, reaction_msg.message_id)
        bot.delete_message(chat_id, loading_msg.message_id)

        # Send sticker after video
        sticker = bot.send_sticker(chat_id, STICKER_AFTER_VIDEO)
        threading.Thread(target=lambda: (time.sleep(6), bot.delete_message(chat_id, sticker.message_id))).start()

    except Exception as e:
        bot.send_message(chat_id, f"❌ Failed to download video:\n`{e}`", parse_mode="Markdown")

# === RUN BOT ===
if __name__ == "__main__":
    print("📡 Video Saver Bot is running...")
    bot.infinity_polling(skip_pending=True)